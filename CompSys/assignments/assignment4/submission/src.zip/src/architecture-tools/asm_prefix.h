//
// Nis Wegmann, 2017
//
// asm_prefix.h
//

#ifndef __PREFIX_H__
#define __PREFIX_H__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#endif // __PREFIX_H__
