//
// Nis Wegmann, 2017
//
// asm_std.h
//

#ifndef __STD_H__
#define __STD_H__

#include <assert.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

#endif // __STD_H__
